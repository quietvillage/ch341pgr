#!/bin/sh
sudo ./ch341pgr & exit
